# coding: utf-8
import time
import datetime
import socket
import string
from random import *
import os
import subprocess
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import sys

htmldiv = ''
sts = ""
fsflag = 0
memflag = 0
cpuflag = 0
status_msg = 0

def execute_shell(command):
    stdin, stdout, stderr = os.popen3(command)
    msg = stdout.read()
    result = stderr.read()
    
    if len(result) > 0:
        return result
    else:
        return msg
       
def send_mail(SMTP_Server, portNo, fromAddr, toAddr, subject, mailBody, attachName=None):
     msg = MIMEMultipart()
     msg['From'] = fromAddr
     msg['To'] = toAddr
     msg['Subject'] = subject
     body = mailBody
     msg.attach(MIMEText(body, 'html'))
     if attachName is not None:
         for eachName in attachName:
            try:
                filename = eachName
                attachment = open("/tmp/ansible/output/"+eachName, "rb")
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
                msg.attach(part)
            except:
                print("could not attach file")
     server = smtplib.SMTP(SMTP_Server, portNo)
     server.starttls()
     text = msg.as_string()
     server.sendmail(fromAddr, toAddr, text)
     server.quit()
    
def RandonCodeGenerator():
    min_char = 4
    max_char = 8
    allchar = string.ascii_letters + string.digits
    new_code = "".join (choice (allchar) for x in range (randint (min_char, max_char)))
    return new_code

def LinuxHealthCheck():
    global fsflag
    global memflag
    global cpuflag
    critical_error = ''
    critical_cpuerror = ''
    critical_memerror = ''
    print ("Executing Commands")
    SYS_DATE = execute_shell ("date")
    OS_RELEASE = execute_shell ("cat /etc/redhat-release")
    OS_RELEASE = str (OS_RELEASE).strip ()
    HOSTNAME = execute_shell ("uname -n |awk '{print $1}'")
    OS_ARCH = execute_shell ("uname -m")
    OS_KERNELVERSION = execute_shell ("uname -r")
    UPTIME = execute_shell ("uptime|awk -F' ' '{print $3, $4,  $8, $9, $10, $11, $12}'")
    READ_ONLY_FS = execute_shell (
        "cat /proc/mounts|egrep -i 'ext4 | ext3 | xfs | gfs | gfs2 | btrfs'|grep -w ro|awk '{print $2}'")
    if len (READ_ONLY_FS) == 0:
        READ_ONLY_FS = 'No Read only FS found'
    ZOMBIE = execute_shell ("""ps aux|grep -v grep|grep -w Z|awk '{print $1, $2, $(NF-1), $NF}'""")
    if len (ZOMBIE) == 0:
        ZOMBIE = 'No Zombie process found'
    INODE = execute_shell ("df -ih -P --local|awk '{print $1,$5}'|column -t")
    MEMORY = execute_shell ("sar -r 2 5")
    FS_USAGE = execute_shell ("df -h -P --local")
    CPU_Load = execute_shell ("sar 2 5")
    LNX_VERSION = execute_shell (
        "cat /proc/version|awk -F 'version' '{print $2}'|awk '{print $1}'|cut -d 'e' -f 2|cut -b 1,2")

    if "l7" in LNX_VERSION:
        ntpd = execute_shell ("systemctl status ntpd|grep Active|column -t")
        if "could not be found" in ntpd:
            ntpd = '<span style="color:red;"> Not available </span>\n'
        crond = execute_shell ("systemctl status crond|grep Active|column -t")
        if "could not be found" in crond:
            crond = '<span style="color:red;"> Not available </span>\n'
        xinetd = execute_shell ("systemctl status xinetd|grep Active|column -t")
        if "could not be found" in xinetd:
            xinetd = '<span style="color:red;"> Not available </span>\n'
        syslogd = execute_shell ("systemctl status syslogd|grep Active|column -t")
        if "could not be found" in syslogd:
            syslogd = '<span style="color:red;"> Not available </span>\n'
        portmap = execute_shell ("systemctl status portmap|grep Active|column -t")
        if "could not be found" in portmap:
            portmap = '<span style="color:red;"> Not available </span>\n'

    if "l6" in LNX_VERSION or "l5" in LNX_VERSION:
        ntpd = execute_shell ("/etc/init.d/ntpd status")
        if "No such file or directory" in ntpd:
            ntpd = '<span style="color:red;"> Not available </span>\n'
        crond = execute_shell ("/etc/init.d/crond status")
        if "No such file or directory" in crond:
            crond = '<span style="color:red;"> Not available </span>\n'
        xinetd = execute_shell ("/etc/init.d/xinetd status")
        if "No such file or directory" in xinetd:
            xinetd = '<span style="color:red;"> Not available </span>\n'
        syslogd = execute_shell ("/etc/init.d/syslogd status")
        if "No such file or directory" in syslogd:
            syslogd = '<span style="color:red;"> Not available </span>\n'
        portmap = execute_shell ("/etc/init.d/portmap status")
        if "No such file or directory" in portmap:
            portmap = '<span style="color:red;"> Not available </span>\n'

    CLUSTER_COMMANDS = ['/opt/VRTSvcs/bin/hastatus -sum', 'pcs status', 'clustat']
    count = 0
    for each_cluster in CLUSTER_COMMANDS:
        CLUSTER_STATUS = execute_shell (each_cluster)
        if "not found" in CLUSTER_STATUS or "No such file or directory" in CLUSTER_STATUS:
            count += 1
    if ( count == 3 ):
        CLUSTER_STATUS = '<span style="color:red;"> Cluster Not Configured </span>\n'

#################################################################################################################################

    percentcpu_idle = execute_shell ("sar 2 5|grep Average|awk '{print $NF}'")
    percentmem_used = execute_shell ("sar -r 2 5|grep Average|awk '{print $4}'")
    percentfs_used = execute_shell ("df -h -P --local|sed -e '1d'|awk '{print $(NF-1)}'|sed 's/%//g'")
    percentfs_used = percentfs_used.split ("\n")
    percentmem_used = str (percentmem_used).strip()
    percentcpu_idle = str (percentcpu_idle).strip()
    modal_id = RandonCodeGenerator ()

#################################################################################################################################

    _outlist = str (INODE).split ("\n")
    _outlist = list (filter (None, _outlist))
    INODE_USAGE = str (_outlist[0]) + '\n'
    for line in _outlist[1:]:
        linlist = line.split (" ")
        str_list = list (filter (None, linlist))
        checkvalue = str_list[-1].strip()
        checkvalue = checkvalue[:-1]
        checkvalue = str (checkvalue)
        if checkvalue != '':
            if float (checkvalue) > 90:
                INODE_USAGE += """<span style="color:red;">""" + str (line) + """</span>\n"""
            elif float (checkvalue) < 90 and float (checkvalue) > 80:
                INODE_USAGE += """<span style="color:orange;">""" + str (line) + """</span>\n"""
            else:
                INODE_USAGE += """<span>""" + str (line) + """</span>\n"""

#################################################################################################################################
### FS_USAGE ###
    outlist = str (FS_USAGE).split ("\n")
    outlist = list (filter (None, outlist))
    FA_DATA = str (outlist[0]) + '\n'
    for line in outlist[1:]:
        linlist = line.split (" ")
        str_list = list (filter (None, linlist))
        checkvalue = str_list[-2]
        checkvalue = checkvalue[:-1]
        checkvalue = str (checkvalue)
        fspath = str_list[-1]
        if float (checkvalue) >= 90:
            fsflag = 1
            find_files = "find %s -type f -size +5M -exec du -sh {} + | sort -rn | head -5" % (fspath)
            results = execute_shell (find_files)
            critical_error += '<p> FS ' + str (fspath) + ' is above 90 </p>'
            critical_error += """<span style="color:red;">""" + str (results) + """</span>"""
            critical_error += '''\n'''
            FA_DATA += """<span style="color:red;">""" + str (line) + """</span>\n"""
        elif float (checkvalue) < 90 and float (checkvalue) > 80:
            fsflag = 1
            find_files = "find %s -type f -size +5M -exec du -sh {} + | sort -rn | head -5" % (fspath)
            results = execute_shell (find_files)
            critical_error += '<p> FS ' + str (fspath) + ' is above 90 </p>'
            critical_error += """<span style="color:red;">""" + str (results) + """</span>"""
            critical_error += '''\n'''
            FA_DATA += """<span style="color:orange;">""" + str (line) + """</span>\n"""
        else:
            FA_DATA += """<span>""" + str (line) + """</span>\n"""
#################################################################################################################################
### CPU_USAGE ###
    if float (percentcpu_idle) <= 10:
        cpuflag = 1
        find_processes = "ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head"
        results = execute_shell (find_processes)
        # critical_cpuerror += '<p> High CPU consuming Processes </p>'
        critical_cpuerror += """<span style="color:red;">""" + str (results) + """</span>"""
        critical_cpuerror += '''\n'''
    elif (float (percentcpu_idle) > 10 and float (percentcpu_idle) < 20):
        cpuflag = 1
        find_processes = "ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head"
        results = execute_shell (find_processes)
        # critical_cpuerror += '<p> High CPU consuming Processes </p>'
        critical_cpuerror += """<span style="color:red;">""" + str (results) + """</span>"""
        critical_cpuerror += '''\n'''
#################################################################################################################################
###MEM_USAGE ###
    if float (percentmem_used) >= 90:
        memflag = 1
        find_processes = "ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head"
        results = execute_shell (find_processes)
        # critical_memerror += '<p> High CPU consuming Processes </p>'
        critical_memerror += """<span style="color:red;">""" + str (results) + """</span>"""
        critical_memerror += '''\n'''
    elif (float (percentmem_used) > 80 and float (percentmem_used) < 90):
        memflag = 1
        find_processes = "ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head"
        results = execute_shell (find_processes)
        # critical_memerror += '<p> High CPU consuming Processes </p>'
        critical_memerror += """<span style="color:red;">""" + str (results) + """</span>"""
        critical_memerror += '''\n'''
#################################################################################################################################

    max_fs_value = max (percentfs_used)
    max_fs_value = int (max_fs_value)
    if max_fs_value > 80 and max_fs_value < 90:
        sts = "warning"
    elif max_fs_value > 90:
        sts = "critical"
    else:
        sts = "ok"
    if float (percentcpu_idle) <= 10 or float (percentmem_used) >= 90 or "critical" in sts:
        status_msg = 1
    elif (float (percentcpu_idle) > 10 and float (percentcpu_idle) < 20) or (
            float (percentmem_used) > 80 and float (percentmem_used) < 90) \
            or "warning" in sts:
        status_msg = -1
    else:
        status_msg = 0

###############################################################################################################################

    if status_msg == -1:
        htmldiv = '<td><div class="card-warning"><a class="button-warning" href="#' + str (
            modal_id) + '"><h4>' + str (HOSTNAME) + ' </h4></a></div></td>'
    elif status_msg == 1:
        htmldiv = '<td><div class="card-critical"><a class="button-critical" ' \
                  'href="#' + str (modal_id) + '"><h4>' + str (HOSTNAME) + '</h4> </a> </div></td>'
    else:
        htmldiv = '<td><div class="card-ok"><a class="button-ok" href="#' + str (modal_id) \
                  + '"><h4>' + str (HOSTNAME) + '</h4> </a></div></td>'

##############################################################################################################################

    modaldatas = """ <div id='""" + str (modal_id) + """' class="overlay">
        <div class="popup">
            <h2>UNIX HEALTH CHECK REPORT on """ + str (SYS_DATE) + """</h2>
            <div class="content">
              	<table>
				<tr>
				<th colspan=2 style='text-align:center'><h3>System Information</h3></th>
				</tr>
				<tr>
				<th>HOSTNAME:</th>
				<th>OS_RELEASE:</th>
				</tr>
				<tbody>
				<tr>
					<td><pre><h3>""" + str (HOSTNAME) + """</h3></td>
					<td><pre><h3>""" + str (OS_RELEASE) + """</h3></td>					
				</tr>
				</tbody>
			</table>
			<table>
				<tr>
				    <th>OS_KERNELVERSION:</th>
				    <th>OS_ARCH:</th>
				    <th>UPTIME:</th>			    					
				</tr>
				<tbody>
				<tr>
				    <td><pre><h3>""" + str (OS_KERNELVERSION) + """</h3></td>
				    <td><pre><h3>""" + str (OS_ARCH) + """</h3></td>
				    <td><pre><h3>""" + str (UPTIME) + """</h3></td>
				</tr>
				</tbody>
			</table>
			    <table>
				<tr>			    
					<th>READ_ONLY_FS:</th>
					<th>ZOMBIE:</th>					
				</tr>
				<tbody>
				<tr>
					<td><pre><h3>""" + str (READ_ONLY_FS) + """</h3></td>
					<td><pre><h3>""" + str (ZOMBIE) + """</h3></td>
				</tr>
				</tbody>
			</table>
			<table>
				<tr>
					<th>FS_USAGE:</th>
					<th>INODE USAGE:</th>
				</tr>
				<tbody>
				<tr>
				    <td style="     text-align: justify;     padding-left: 6%; "><pre><h3>""" + str (FA_DATA) + """</h3></td>
				    <td><pre><h3>""" + str (INODE_USAGE) + """</h3></td>
				</tr>
				</tbody>
			</table>
				<table>
				<tr>
				    <th>MEMORY:</th>
				</tr>
				<tbody>
				<tr>
				    <td><pre><h3>""" + str (MEMORY) + """</h3></td>	
				</tr>
				</tbody>
			</table>
				<table>
				<tr>
					<th>CPU UTILIZATION:</th>
				</tr>
				<tbody>
				<tr>
					<td><pre><h3>""" + str (CPU_Load) + """</h3></td>
				</tr>
				</tbody>
			</table>
				<table>
				<tr>
					<th>CLUSTER_STATUS:</th>
				</tr>
				<tbody>
				<tr>
					<td><pre><h3>""" + str (CLUSTER_STATUS) + """</th>
				</tr>
				</tbody>
			</table>
			    </table>
				<table>
				<tr>
				    <th>SERVICE STATUS:</th>
				</tr>
				<tbody>      
				<tr>
				    <td><pre><h3> NTPD: """ + str (ntpd) + """</h3><br><h3>CROND: """ + str (crond) + \
                 """</h3><br><h3>XINETD: """ + str (xinetd) + """</h3><br><h3>SYSLOGD: """ + str (syslogd) + \
                 """</h3><br><h3>PORTMAP: """ + str (portmap) + """</h3></td>
				</tr>
				</tbody>
			</table>"""
    if cpuflag == 1:
        modaldatas += """ <table>
				<tr>			    
					<th>TOP CPU CONSUMING PROCESSES:</th>					
				</tr>
				<tbody>
				<tr>
					<td style="text-align: justify;padding-left: 6%; "><pre><h3>""" + str (critical_cpuerror) + """</h3></td>
				</tr>
				</tbody>
			</table>"""
    if memflag == 1:
        modaldatas += """<table>
				<tr>			    
					<th>TOP MEMORY CONSUMING PROCESSES:</th>					
				</tr>
				<tbody>
				<tr>
					<td style="text-align: justify;padding-left: 6%; "><pre><h3>""" + str (critical_memerror) + """</h3></td>
				</tr>
				</tbody>
			</table>"""
    if fsflag == 1:
        modaldatas += """<table>
				<tr>			    
					<th>LARGE FILES:</th>					
				</tr>
				<tbody>
				<tr>
					<td style="text-align: justify;padding-left: 6%; "><pre><h3>""" + str (critical_error) + """</h3></td>
				</tr>
				</tbody>
			</table>"""
    modaldatas += """<br> 
			<br>
			<br> 
			<br>
			<br> 
			<br>
			<br> 
			<br>
            </div>
        </div>
    </div>"""
    output_datahtml = {1: str (htmldiv), 2: str (modaldatas)}
    return output_datahtml
    
def main():
    print ("Fn Initialised")
    host = (execute_shell("hostname")).split("\n")[0]
    modal_data = ""
    results = {}
    try:
        os_flavour = execute_shell("uname -s")
        current_time = str(datetime.datetime.now ()).replace(" ","_").replace(":","-").split(".")[0]
        
        if "Linux" in os_flavour:
            print ("In Linux Fn")
            results = LinuxHealthCheck ()
            modal_data += results[2]
        else:
            modal_id = RandonCodeGenerator ()
            modal_data += """<div id='""" + modal_id + """' class="overlay">
                            <div class="popup">
                                <h2 style="color:red;">Server NOT Reachable</h2>
                                <a class="close" href="#">&times;</a>
                            </div>
                        </div>"""
                        
        html_report = """  <!DOCTYPE html>
                            <html>
                            <head>
                                <meta name="viewport" content="width=device-width, initial-scale=1">
                                <style>
                                    body {
                                        margin: 0;
                                        background: #0a0a0a;
                                    }

                                    table {
                                        border: 1px solid #0a0a0a;
                                        border-collapse: collapse;
                                        margin: 0;
                                        padding: 0;
                                        width: 100%;
                                        table-layout: fixed;
                                    }

                                        table caption {
                                            font-size: 1.5em;
                                            margin: .5em 0 .75em;
                                        }

                                        table tr {
                                            background-color: white;
                                            padding: .35em;
                                        }
                                        th{
                                        padding-top:13px !important;
                                        }
                                        table th,
                                        table td {
                                            padding: 0px;
                                            text-align: center;
                                        }

                                        table th {
                                            font-size: .85em;
                                            letter-spacing: .1em;
                                            text-transform: uppercase;
                                        }

                                        @media screen and (max-width: 600px) {
                                            table {
                                                border: 0;
                                            }

                                                table caption {
                                                    font-size: 1.3em;
                                                }

                                                table thead {
                                                    border: none;
                                                    clip: rect(0 0 0 0);
                                                    height: 1px;
                                                    margin: -1px;
                                                    overflow: hidden;
                                                    padding: 0;
                                                    position: absolute;
                                                    width: 1px;
                                                }

                                                table tr {
                                                    border-bottom: 3px solid #0a0a0a;
                                                    display: block;
                                                    margin-bottom: .625em;
                                                }

                                                table td {
                                                    border-bottom: 1px solid #ddd;
                                                    display: block;
                                                    font-size: .8em;
                                                    text-align: right;
                                                }

                                                    table td::before {
                                                        /*
                                                * aria-label has no advantage, it won't be read inside a table
                                                content: attr(aria-label);
                                                */
                                                        content: attr(data-label);
                                                        float: left;
                                                        font-weight: bold;
                                                        text-transform: uppercase;
                                                    }

                                                    table td:last-child {
                                                        border-bottom: 0;
                                                    }
                                        }
                                        h1 {
                                            text-align: center;
                                            font-family: Tahoma, Arial, sans-serif;
                                            color: #06D85F;
                                            margin: 80px 0;
                                        }

                                        .overlay {
                                            position: fixed;
                                            top: -60px;
                                            bottom: 0;
                                            left: 0;
                                            right: 0;
                                            background: rgba(0, 0, 0, 0.7);
                                            transition: opacity 500ms;
                                            visibility: visible;
                                        }

                                            .overlay:target {
                                                visibility: visible;
                                                opacity: 1;
                                            }

                                        .popup {
                                            margin: 70px auto;
                                            padding: 20px;
                                            background: #bfb3b3;
                                            border-radius: 5px;
                                            width: 95%;
                                            height : 100%;
                                            position: relative;
                                            transition: all 5s ease-in-out;
                                        }

                                            .popup h2 {
                                                margin-top: 0;
                                                color: #333;
                                                font-family: Tahoma, Arial, sans-serif;
                                            }

                                            .popup .close {
                                                position: absolute;
                                                top: 18px;
                                                right: 30px;
                                                transition: all 200ms;
                                                font-size: 30px;
                                                font-weight: bold;
                                                text-decoration: none;
                                                color: #333;
                                            }

                                                .popup .close:hover {
                                                    color: #06D85F;
                                                }

                                            .popup .content {
                                                max-height: 100%;
                                                overflow: scroll;
                                            }

                                        @media screen and (max-width: 700px) {
                                            .box {
                                                width: 70%;
                                            }

                                            .popup {
                                                width: 100%;
                                            }
                                        }
                                    </style>
                                </head>
                                <body>
                                    """ + modal_data + """
                                </body>
                                </html> """
                
        print ("Completed")
        print("Output files are created at the location /tmp/ansible/output/ on target server")
        infile = host + "_healthcheck_report_" + current_time +".html"
        filepath1 = os.path.join('/tmp/ansible/output/',infile)
        if not os.path.exists('/tmp/ansible/output/'):
            os.makedirs('/tmp/ansible/output/')
        with open (filepath1, 'w') as log_file:
            log_file.write (html_report + "\r\n")
        body = "Please find attached the Health Check Report for "+host+".<br><br>Output files are created at location /tmp/ansible/output/ on target server.<br><br><br><br> <b>Please donot reply to this email id .If you have any queries, please contact us at Xerox.Wipro.Holmes.Automation@xerox.com<b>"
        try:
            send_mail("forwarder.mail.xerox.com", 25, "Holmes.BOT@xerox.com", "sourav.bhardwaj@xerox.com",
                "Health Check Report",body,[infile])
            print("Health Check Report mail sent")
        except Exception as e:
            print(e)
    except Exception as ex:
            print("Error with "+ host+" and Error is "+ str(ex))
            try:
                send_mail("forwarder.mail.xerox.com", 25, "Holmes.BOT@xerox.com", "sourav.bhardwaj@xerox.com",
                          "Health Check Report","Error with "+ host+" and Error is "+ str(ex)+".<br><br><br><br> <b>Please donot reply to this email id .If you have any queries, please contact us at Xerox.Wipro.Holmes.Automation@xerox.com<b>",None)
                print("Mail sent with error")
            except Exception as e:
                    print(e)

main ()
