# coding: utf-8
import time
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import itertools
import csv
import socket
import os
import datetime

def diff(a, b):
    y = []
    for x in a:
        if x not in b:
            y.append(x)
        else:
            b.remove(x)
    return y

def isplit(iterable,splitters):
    return [list(g) for k,g in itertools.groupby(iterable,lambda x:x in splitters) if not k]

def execute_command(command):
    stdin, stdout, stderr = os.popen3(command)
    msg = stdout.read().decode('utf-8')
    result = stderr.read().decode('utf-8')
    
    if len(result) > 0:
        return result
    else:
        return msg

def send_mail(SMTP_Server, portNo, fromAddr, toAddr, subject, mailBody, attachName=None):
     msg = MIMEMultipart()
     msg['From'] = fromAddr
     msg['To'] = toAddr
     msg['Subject'] = subject
     body = mailBody
     msg.attach(MIMEText(body, 'html'))
     if attachName is not None:
         for eachName in attachName:
            try:
                filename = eachName
                attachment = open("/tmp/ansible/output/"+eachName, "rb")
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
                msg.attach(part)
            except:
                print("could not attach file")
     server = smtplib.SMTP(SMTP_Server, portNo)
     server.starttls()
     text = msg.as_string()
     server.sendmail(fromAddr, toAddr, text)
     server.quit()

post_check_commands_5_6=["uname -a", "uptime", "cat /etc/redhat-release", "dmidecode -s system-product-name","lsblk",
                    "vmware-toolbox-cmd -v", "lvs", "vgs", "pvs","cat /etc/resolv.conf",
                    "cat /etc/hosts","ifconfig -a", "netstat -nr", "mount", "df -h", "fdisk -l", "cat /etc/fstab", "cat /etc/grub.conf",
                    "cat /etc/ntp.conf","netstat -tulnp","ps aux","cat /etc/hosts | wc -l", "cat /etc/resolv.conf | wc -l",
                    "cat /etc/grub.conf | wc -l","cat /etc/ntp.conf | wc -l","ps aux | wc -l","netstat -tulnp | wc -l",
                    "netstat -nr | wc -l", "ifconfig -a | wc -l", "df -h | wc -l","mount | wc -l", "cat /etc/fstab | wc -l",
                    "fdisk -l | wc -l","lvs | wc -l", "vgs | wc -l", "pvs | wc -l", "cat /etc/grub2.cfg", "cat /etc/udev/rules.d/91-asm.rules",
                    "cat /etc/udev/rules.d/91-asm.rules | wc -l", "powermt display dev=all", "multipath -l", "ntpq -p", "service --status-all", "chkconfig --list", "rpm -qa", "yum repolist"]

post_check_commands_7=["uname -a", "uptime", "cat /etc/redhat-release", "dmidecode -s system-product-name","lsblk",
                    "vmware-toolbox-cmd -v", "lvs", "vgs", "pvs","cat /etc/resolv.conf",
                    "cat /etc/hosts","ifconfig -a", "netstat -nr", "mount", "df -h", "fdisk -l", "cat /etc/fstab", "cat /etc/grub.conf",
                    "cat /etc/ntp.conf","netstat -tulnp","ps aux","cat /etc/hosts | wc -l", "cat /etc/resolv.conf | wc -l",
                    "cat /etc/grub.conf | wc -l","cat /etc/ntp.conf | wc -l","ps aux | wc -l","netstat -tulnp | wc -l",
                    "netstat -nr | wc -l", "ifconfig -a | wc -l", "df -h | wc -l","mount | wc -l", "cat /etc/fstab | wc -l",
                    "fdisk -l | wc -l","lvs | wc -l", "vgs | wc -l", "pvs | wc -l", "cat /etc/grub2.cfg", "cat /etc/udev/rules.d/91-asm.rules",
                    "cat /etc/udev/rules.d/91-asm.rules | wc -l", "powermt display dev=all", "multipath -l", "ntpq -p",
                    "rpm -qa", "yum repolist"]

post_check_commands_aix=["date","uname -auL","oslevel -s","bootlist -m normal -o","bootinfo -b","lscfg |grep bootinfo -b","bootinfo -s bootinfo -b","ls -ldr /usr/java*","instfix -i |grep -E 'ML|SP|TL'",
                        "lparstat -i","uptime","lppchk -vm3","lsps -s","lsps -a","ifcongif -a","netstst -rn","lasttr -E1 inet0","lsdev -Cc adapter |grep ent","lscfg |grep ent","lsvg |sort |cat -n",
                        "lsvg -o |sort |cat -n","lsvg -o|lsvg -i","lsvg -o|lsvg -il","lsvg -o |lsvg -ip","df -g |sort","lsfs -a","lsattr -El sys0","lscfg","lsdev -Cc adapter","lspath",
                        "datapath query adapter","datapath query wwpn","datapath query device","df -g |wc -l","lspath |grep -v Enable","lslpp -l |grep SDD",'if [ -f /opt/IBM/ITM/bin/cinfo ];then /opt/IBM/ITM/bin/cinfo -r; else echo "ITM Not found"; fi',
                        "ps -ef | grep lcf","ps -ef |grep dsmc","vmo -a","no -a","ioo -a","raso -a","schedo -a","lslpp -l","lssrc -a",
                        '[ "$WHOAMI" = "root" ] && if [ -f /etc/es/objrepos/HACMPcluster ]; then /usr/es/sbin/cluster/utilities/clRGinfo;  /usr/es/sbin/cluster/utilities/cllsres;  /usr/es/sbin/cluster/utilities/clshowres;  /usr/es/sbin/cluster/utilities/cllsserv;  /usr/es/sbin/cluster/utilities/cllsif; fi']
def patching_cmd(infile,htmlfile,os_name,os_version):
    if 'AIX' in os_name:
        commands = post_check_commands_aix
    elif 'Linux' in os_name:
        if "el5" in os_version or 'el6' in os_version:
            commands = post_check_commands_5_6
        elif "el7" in os_version:
            commands = post_check_commands_7
        else:
            raise Exception('Linux Version is neither of 5,6 or 7')
    else:
        raise Exception('OS is neither Linux nor AIX')
    
    f = open(infile,"w")
    list = []
    modaldatas = """<div class="content">
              	<table>
				<tr>
				<th colspan=2 style='text-align:center'><h3>Postcheck Commands Output</h3></th>
				</tr>
				<tr>
				<th>COMMAND:</th>
				<th>OUTPUT:</th>
				</tr>
				<tbody>"""
    for i in commands:
        msg = execute_command(i)
        modaldatas += """<tr>
					<td><pre><h3>""" + str(i) + """</h3></td>
					<td><pre><h3>""" + str(msg.encode('utf-8')) +"""</h3></td>					
				</tr>"""
        list.append(msg)
    
    if "el7" in os_version:
        rhel7_more_commands=["systemctl list-units --type service --all","systemctl list-unit-files --type=service"]
        for i in rhel7_more_commands:
            msg = execute_command(i)
            modaldatas += """<tr>
					<td><pre><h3>""" + str(i) + """</h3></td>
					<td><pre><h3>""" + str(msg.encode('utf-8')) +"""</h3></td>					
				</tr>"""
            list.append(msg)
        commands+=rhel7_more_commands
    
    for i in range(len(list)):
        f.write("Command :"+ commands[i]+"\n")
        f.write(str((list[i]).encode('utf-8')))
        f.write("\n"+"----------------------------------------------------------------------------------"+"\n")

    boot = "df -Th /boot | awk '{print $6}' | tail -1"
    msg = execute_command(boot)
    f.write("Command :" + boot + "\n")
    if msg.split('\n')[-2] > '70%':
        f.write("/boot utilization is more than 70%" + "\n" + "\n")
        modaldatas += """<tr>
					<td><pre><h3>""" + boot + """</h3></td>
					<td><pre><h3>""" + "/boot utilization is more than 70%" +"""</h3></td>					
				</tr>"""
    else:
        f.write("/boot utilization is less than 70%" + "\n" + "\n")
        modaldatas += """<tr>
					<td><pre><h3>""" + boot + """</h3></td>
					<td><pre><h3>""" + "/boot utilization is less than 70%" +"""</h3></td>					
				</tr>"""
    f.write("----------------------------------------------------------------------------------" + "\n")

    rpms = 'rpm -qa --queryformat "%{NAME}.%{ARCH}\n" | sort | uniq --'
    msg = execute_command(rpms)
    f.write('Command :' + 'rpm -qa --queryformat "%{NAME}.%{ARCH}\\n" | sort | uniq --' + '\n')
    if len(msg) > 0:
        f.write("Duplicate rpms are present" + "\n" + "\n")
        modaldatas += """<tr>
					<td><pre><h3>""" + rpms + """</h3></td>
					<td><pre><h3>""" + "Duplicate rpms are present" +"""</h3></td>					
				</tr>"""
    else:
        f.write("Duplicate rpms not present" + "\n" + "\n")
        modaldatas += """<tr>
					<td><pre><h3>""" + rpms + """</h3></td>
					<td><pre><h3>""" + "Duplicate rpms not present" +"""</h3></td>					
				</tr>"""
    f.write("----------------------------------------------------------------------------------" + "\n")
    modaldatas += """</tbody>
			</table></div>"""
            
    fhtml = open(htmlfile, "w")
    html_report = """<!DOCTYPE html>
                    <html>
                    <head>
						<meta name="viewport" content="width=device-width, initial-scale=1">
						<style>
						body {
						margin: 0;
						background: white;
						}

						 .navbar {
						overflow: hidden;
						background-color: #394c57;
						position: fixed;
						top: 0;
						width: 100%;
						}

						 .main {
						padding: 16px;
						margin-top: 50px;
						height: 1500px;
						}


						 table {
						margin: 0;
						padding: 0;
						width: 100%;
						table-layout: fixed;
						}

						 table caption {
						font-size: 1.5em;
						margin: .5em 0 .75em;
						}

						 table tr {
						background-color: white;
						padding: .35em;
						}
						th{
						padding-top:13px !important;
						}
						table th,
						table td {
						padding: 0px;
						text-align: center;
						}

						 table th {
						font-size: .85em;
						letter-spacing: .1em;
						text-transform: uppercase;
						}


						h1 {
						text-align: center;
						font-family: Tahoma, Arial, sans-serif;
						color: #06D85F;
						margin: 80px 0;
						}

						 h2 {
						margin-top: 0;
						color: #333;
						font-family: Tahoma, Arial, sans-serif;
						}

						}
						</style>
						</head>
                    <body>
                        <div class="navbar">
                            <h3 style="margin-left : 10px; color:#98a6ad;">POST CHECK REPORT - """ + str (
        datetime.datetime.now ()) + """</h3>
                        </div> """ + modaldatas + """
                    </body>
                    </html> """
    fhtml.write(html_report)
    fhtml.close()
    f.close()

def  main():
    try:
        os_name = execute_command("uname -s")
        os_version = execute_command("uname -r")
        host = (execute_command("hostname")).split("\n")[0]
        current_time = str(datetime.datetime.now ()).replace(" ","_").replace(":","-").split(".")[0]
        
        infile = host + "_postcheck_" + current_time +".txt"
        htmlfile = host + "_postcheck_" + current_time +".html"
        filepath1 = os.path.join('/tmp/ansible/output/',infile)
        filepath2 = os.path.join('/tmp/ansible/output/',htmlfile)
        if not os.path.exists('/tmp/ansible/output/'):
            os.makedirs('/tmp/ansible/output/')
        
        print("Post Check Commands Are Running On " + host + " ...")
        patching_cmd(filepath1,filepath2, os_name,os_version)
        print("Post Check Commands Running Over On " + host + " ...")
        print("Output files are created at the location /tmp/ansible/output/ on target server")
        body1 = "Please find attached the Postcheck Command Outputs for " + host+".<br><br>Output files are created at location /tmp/ansible/output/ on target server.<br><br><br><br> <b>Please donot reply to this email id .If you have any queries, please contact us at Xerox.Wipro.Holmes.Automation@xerox.com<b>"
        try:
            send_mail("forwarder.mail.xerox.com", 25, "Holmes.BOT@xerox.com", "sourav.bhardwaj@xerox.com",
                    "Post Check Output",body1,[infile,htmlfile])
            print("PostCheck mail sent")
        except Exception as e:
            print(e)
        
        files = []
        filepath = os.path.join('/tmp/ansible/output/')
        for i in os.listdir(filepath):
            if os.path.isfile(os.path.join(filepath,i)) and i.startswith(host+"_precheck_") and i.endswith (".txt"):
                files.append(os.path.join('/tmp/ansible/output/',i))
        if len(files)==0:
            raise Exception("PreCheck file not found");
        latest_file = max(files, key=os.path.getctime)
        print("Comparing with precheck file " + latest_file)
        file1 = open(latest_file, "r").read().split("\n")
        file2 = open(filepath1, "r").read().split("\n")

        line = "----------------------------------------------------------------------------------"
        newlist1 = isplit(file1, (line,))
        newlist2 = isplit(file2, (line,))
        
        list_precheck = []
        list_postcheck = []

        for i in range(len(newlist1)):
            list_precheck.append(diff(newlist1[i], newlist2[i]))
        for i in range(len(newlist1)):
            list_postcheck.append(diff(newlist2[i], newlist1[i]))
        

        final_precheck_list = []
        for i in list_precheck:
            
            list_precheck_string = "\n".join(i)
            
            final_precheck_list.append(list_precheck_string)

        final_postcheck_list = []
        for i in list_postcheck:
            
            list_postcheck_string = "\n".join(i)
            final_postcheck_list.append(list_postcheck_string)

        csvfile = host + '_comparison_' +current_time+'.csv'
        filepath3 = os.path.join('/tmp/ansible/output/',csvfile)
        file3 = open(filepath3 , 'w')
        file3.write("Commands" + "," + "Difference Found(Yes/No)" + "," + "PreCheck" + "," + "PostCheck" + "\n")

        if "el5" in os_version or 'el6' in os_version:
            commands = post_check_commands_5_6
        elif "el7" in os_version:
            commands = post_check_commands_7
        else:
            raise Exception('Version is neither of 5,6 or 7')

        for i, j, m in zip(commands, final_precheck_list, final_postcheck_list):
            file3.write((i + ","))
            if j != '':
                file3.write("Yes" + "," + "\"" + j + "\"" + ",")
                file3.write("\"" + m + "\"" + ",")
                
                file3.write("\n")
            else:
                file3.write("No" + "\n")
        file3.close()
        body2 = "Please find attached the Comparison File for "+host+".<br><br>Output files are created at location /tmp/ansible/output/ on target server.<br><br><br><br> <b>Please donot reply to this email id .If you have any queries, please contact us at Xerox.Wipro.Holmes.Automation@xerox.com<b>"
        try:
            send_mail("forwarder.mail.xerox.com", 25, "Holmes.BOT@xerox.com", "sourav.bhardwaj@xerox.com",
                      "PreCheck and PostCheck Comparison for " + host,body2,[csvfile])
            print("Comparison mail sent")
        except Exception as e:
                print(e)
    
    except Exception as ex:
        print("Error with " + host + " and Error is " + str(ex))
        try:
            send_mail("forwarder.mail.xerox.com", 25, "Holmes.BOT@xerox.com", "sourav.bhardwaj@xerox.com",
                     "Postcheck Commands output","Error with "+ host+" and Error is "+ str(ex)+"<br><br><br><br> <b>Please donot reply to this email id .If you have any queries, please contact us at Xerox.Wipro.Holmes.Automation@xerox.com<b>",None)
            print("Mail sent with error")
        except Exception as e:
            print(e)

main()